package utils;

public enum ParameterType 
{
	INTEGER,
	STRING,
	DATE,
	HOUR,
	PASSWD,
	BOOLEAN
}

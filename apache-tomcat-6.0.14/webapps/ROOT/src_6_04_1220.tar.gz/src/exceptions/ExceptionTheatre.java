package exceptions;

public class ExceptionTheatre extends Exception {

	public ExceptionTheatre() {
		// TODO Auto-generated constructor stub
	}

	public ExceptionTheatre(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ExceptionTheatre(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ExceptionTheatre(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
